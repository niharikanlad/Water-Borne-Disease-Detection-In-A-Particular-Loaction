const quizData = [
  {
    question: 'What is the single most effective way to prevent the spread of waterborne diseases?',
    options: ['Boiling water', 'Filtering water.', 'Washing hands with soap and water.', 'Adding water purification tablets.'],
    answer: 'Washing hands with soap and water.',
  },
  {
    question: 'How much clean water does an adult need to drink each day?',
    options: ['1 liter', '5-10 liters', '2-4 liters', 'Depends on activity level and climate.'],
    answer: '2-4 liters',
  },
  {
    question: 'Which of the following activities can contaminate your drinking water?',
    options: [' Storing water in a closed container.', 'Keeping drinking cups clean.', 'Leaving a lid off your water storage container.', 'Washing fruits and vegetables before eating'],
    answer: 'Leaving a lid off your water storage container.',
  },
  {
    question: 'Which of these water sources is MOST likely to be contaminated with harmful bacteria?',
    options: [' A mountain stream with clear, fast-flowing water.', 'A well maintained rainwater harvesting system.', 'A stagnant pond surrounded by livestock.', 'Bottled water from a reputable brand.'],
    answer: 'A stagnant pond surrounded by livestock.',
  },
  {
    question: 'Which is the largest ocean on Earth?',
    options: [
      'Pacific Ocean',
      'Indian Ocean',
      'Atlantic Ocean',
      'Arctic Ocean',
    ],
    answer: 'Pacific Ocean',
  },
  {
    question: 'Chlorine is commonly used to disinfect water because:',
    options: ['It improves the taste and smell.', 'It is inexpensive and readily available.', 'It kills harmful bacteria and viruses.', 'It adds essential minerals to the water.'],
    answer: 'It is inexpensive and readily available.',
  },
  {
    question: 'What is the primary reason for boiling water before drinking it?',
    options: [
      'To remove sediment and impurities.',
      ' To improve the taste and odor.',
      ' To kill harmful bacteria and parasites.',
      'To cool it down to a comfortable drinking temperature.',
    ],
    answer: 'To cool it down to a comfortable drinking temperature.',
  },
  {
    question: 'Which of the following is NOT a symptom of waterborne illness?',
    options: ['Stomach cramps and diarrhea.', 'Fever and vomiting.', 'Skin rash or allergic reaction.', '* Dehydration and fatigue.'],
    answer: 'Fever and vomiting.',
  },
  {
    question: 'Which of the following statements about bottled water is TRUE?',
    options: [
      'Bottled water is always safer than tap water.',
      'Single-use plastic bottles contribute to environmental pollution.',
      'Investing in a reusable water bottle is a more sustainable choice.',
      'All of the above.',
    ],
    answer: 'All of the above',
  },
  {
    question: 'Improving global water access and sanitation can contribute to:',
    options: ['Poverty reduction and economic development.', ' Improved public health and child survival.', 'Gender equality and educational opportunities.', ' All of the above'],
    answer: ' All of the above',
  },
];

const quizContainer = document.getElementById('quiz');
const resultContainer = document.getElementById('result');
const submitButton = document.getElementById('submit');
const retryButton = document.getElementById('retry');
const showAnswerButton = document.getElementById('showAnswer');

let currentQuestion = 0;
let score = 0;
let incorrectAnswers = [];

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function displayQuestion() {
  const questionData = quizData[currentQuestion];

  const questionElement = document.createElement('div');
  questionElement.className = 'question';
  questionElement.innerHTML = questionData.question;

  const optionsElement = document.createElement('div');
  optionsElement.className = 'options';

  const shuffledOptions = [...questionData.options];
  shuffleArray(shuffledOptions);

  for (let i = 0; i < shuffledOptions.length; i++) {
    const option = document.createElement('label');
    option.className = 'option';

    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'quiz';
    radio.value = shuffledOptions[i];

    const optionText = document.createTextNode(shuffledOptions[i]);

    option.appendChild(radio);
    option.appendChild(optionText);
    optionsElement.appendChild(option);
  }

  quizContainer.innerHTML = '';
  quizContainer.appendChild(questionElement);
  quizContainer.appendChild(optionsElement);
}

function checkAnswer() {
  const selectedOption = document.querySelector('input[name="quiz"]:checked');
  if (selectedOption) {
    const answer = selectedOption.value;
    if (answer === quizData[currentQuestion].answer) {
      score++;
    } else {
      incorrectAnswers.push({
        question: quizData[currentQuestion].question,
        incorrectAnswer: answer,
        correctAnswer: quizData[currentQuestion].answer,
      });
    }
    currentQuestion++;
    selectedOption.checked = false;
    if (currentQuestion < quizData.length) {
      displayQuestion();
    } else {
      displayResult();
    }
  }
}

function displayResult() {
  quizContainer.style.display = 'none';
  submitButton.style.display = 'none';
  retryButton.style.display = 'inline-block';
  showAnswerButton.style.display = 'inline-block';
  resultContainer.innerHTML = `You scored ${score} out of ${quizData.length}!`;
}

function retryQuiz() {
  currentQuestion = 0;
  score = 0;
  incorrectAnswers = [];
  quizContainer.style.display = 'block';
  submitButton.style.display = 'inline-block';
  retryButton.style.display = 'none';
  showAnswerButton.style.display = 'none';
  resultContainer.innerHTML = '';
  displayQuestion();
}

function showAnswer() {
  quizContainer.style.display = 'none';
  submitButton.style.display = 'none';
  retryButton.style.display = 'inline-block';
  showAnswerButton.style.display = 'none';

  let incorrectAnswersHtml = '';
  for (let i = 0; i < incorrectAnswers.length; i++) {
    incorrectAnswersHtml += `
      <p>
        <strong>Question:</strong> ${incorrectAnswers[i].question}<br>
        <strong>Your Answer:</strong> ${incorrectAnswers[i].incorrectAnswer}<br>
        <strong>Correct Answer:</strong> ${incorrectAnswers[i].correctAnswer}
      </p>
    `;
  }

  resultContainer.innerHTML = `
    <p>You scored ${score} out of ${quizData.length}!</p>
    <p>Incorrect Answers:</p>
    ${incorrectAnswersHtml}
  `;
}

submitButton.addEventListener('click', checkAnswer);
retryButton.addEventListener('click', retryQuiz);
showAnswerButton.addEventListener('click', showAnswer);

displayQuestion();