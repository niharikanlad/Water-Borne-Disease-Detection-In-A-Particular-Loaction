from flask import Flask, render_template, request, jsonify
from opencage.geocoder import OpenCageGeocode
import pandas as pd

app = Flask(__name__)

# Replace 'YOUR_OPENCAGE_API_KEY' with your actual OpenCage API key
opencage_api_key = '19879d6363cf492c9e9c19a87df8d508'
geocoder = OpenCageGeocode(opencage_api_key)

# Load the dataset
dataset = pd.read_excel('Bengaluru_dataset.xlsx')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    try:
        data = request.get_json()
        pincode = data.get('searchTerm', '')

        coordinates = geocode_pincode(pincode)
        outbreak_data = get_outbreak_data(pincode)

        if coordinates and outbreak_data:
            return jsonify({'result': {'lat': coordinates['lat'], 'lng': coordinates['lng'], 'location_name': coordinates['location_name'], 'data': outbreak_data}})
        else:
            return jsonify({'error': 'Location not found for the given pincode.'}), 404

    except Exception as e:
        return jsonify({'error': str(e)}), 500

def geocode_pincode(pincode):
    try:
        result = geocoder.geocode(pincode + ", India", no_annotations='1')

        if result and len(result):
            lat = result[0]['geometry']['lat']
            lng = result[0]['geometry']['lng']
            location_name = result[0]['components']['suburb']  # Extract the suburb/area name
            return {'lat': lat, 'lng': lng, 'location_name': location_name}
        else:
            return None
    except Exception as e:
        print(f"Geocoding error for pincode {pincode}: {str(e)}")
        return None

def get_outbreak_data(pincode):
    outbreak_data = dataset[dataset['Pincode'] == int(pincode)]
    
    if not outbreak_data.empty:
        return outbreak_data.to_dict(orient='records')[0]
    else:
        return None

if __name__ == '__main__':
    app.run(debug=True)
